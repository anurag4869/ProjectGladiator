package com.lti.dto;

public class QuestionsDTO {
	private int subjectId;
	
	
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	
	
	

}
