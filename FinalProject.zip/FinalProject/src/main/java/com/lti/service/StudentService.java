package com.lti.service;

import com.lti.entity.TableStudent;

public interface StudentService {
	public void addStudent(TableStudent student);
}
