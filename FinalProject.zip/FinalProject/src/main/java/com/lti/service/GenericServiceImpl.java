package com.lti.service;

public class GenericServiceImpl {

}
